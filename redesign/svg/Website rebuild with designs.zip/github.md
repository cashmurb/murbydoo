repo: cashmurb/murbydoo
branch: main

## Sync history
- 2026-08-20T06:24:22Z — built Home.dc.html homepage.

## Sync history
- 2026-08-20T06:39:51Z — initial homepage + inner pages restyle.

## Last sync
date: 2026-08-20T07:46:55Z

### Updated in this project
- Home.dc.html: pan-transition intro, exact brain-circuit graphic (paths lifted from home_2.svg), precise nav constellation lines, tweaks for accent/muted color + pan speed.
- NavHeader.dc.html: shared fixed nav bar (site name + Brain/Dump/WIPs/World constellation) used across all inner pages.
- Restyled inner pages to the black/white/#D96614 Kode Mono look, content kept, using NavHeader: About.dc.html, Projects.dc.html, Socials.dc.html, Takeaways.dc.html, Writing.dc.html, InProgress.dc.html.
- Takeaways.dc.html rebuilt to match Figma brain_page design: BRAIN watermark, carousel card pulling real content from repo's takeaways.html (6 courses, subtopics as subtitle, links to takeaways-*.html).
- New placeholder pages: WhatAmIDoing.dc.html, Avatar.dc.html ("coming soon").
- All homepage/nav links wired between these .dc.html files for in-tool review.

## Screen map
| Screen | Repo files |
|---|---|
| Home.dc.html | index.html |
| NavHeader.dc.html | (new — nav markup shared by about.html, projects.html, socials.html, takeaways.html, writing.html, inprogress.html) |
| About.dc.html | about.html |
| Projects.dc.html | projects.html |
| Socials.dc.html | socials.html |
| Takeaways.dc.html | takeaways.html |
| Writing.dc.html | writing.html |
| InProgress.dc.html | inprogress.html |
| WhatAmIDoing.dc.html | new page, no repo file yet |
| Avatar.dc.html | new page, no repo file yet |

## Next up
- User will copy this code into the repo themselves; when copying, rename links back to lowercase .html (e.g. About.dc.html -> about.html) to match repo conventions, and give WhatAmIDoing/Avatar real filenames.
- archive.html and the takeaways-*.html subpages not yet restyled (not directly reachable from the new home nav).
